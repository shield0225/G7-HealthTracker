import React from "react";
import "./InfoArea.css";

function Personal() {
  return (
    <>
      <h1>Patient</h1>
    </>
  );
}

export default Personal;
