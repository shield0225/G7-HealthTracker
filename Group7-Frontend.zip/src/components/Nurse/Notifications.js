import React from "react";
import "./InfoArea.css";

function Notifications() {
  return (
    <>
      <div className="form-container-no-grid">
        <img
          src="https://as2.ftcdn.net/v2/jpg/01/89/24/45/1000_F_189244555_ieurJd3t9hSSufU2WB02L9lKuT1ZB1Pj.jpg"
          alt="Symptoms"
          className="underconstruction"
          width="100%"
        />
      </div>
    </>
  );
}

export default Notifications;
