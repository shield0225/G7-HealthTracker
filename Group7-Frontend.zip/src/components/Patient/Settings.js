import React from "react";
import "./InfoArea.css";

function Settings() {
  return (
    <>
      <h1>Patient</h1>
    </>
  );
}

export default Settings;
